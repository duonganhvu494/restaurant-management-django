from django.apps import AppConfig


class RmConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rm'
